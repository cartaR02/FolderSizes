# filepath: e:\Coding-Projects\FolderSizes\foldersizes\__init__.py
# This file is intentionally left blank.